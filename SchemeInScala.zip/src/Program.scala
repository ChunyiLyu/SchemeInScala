// Chunyi Lyu
// Program class, takes in a ArrayBuffer of Expression

import scala.collection.mutable.ArrayBuffer;
class Program (val expressions: ArrayBuffer[Expression]){  
}